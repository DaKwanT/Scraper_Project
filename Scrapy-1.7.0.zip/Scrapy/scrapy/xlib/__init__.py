"""This package contains some third party modules that are distributed along
with Scrapy"""
