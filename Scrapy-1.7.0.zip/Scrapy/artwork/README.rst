:orphan:

Scrapy artwork
==============

This folder contains Scrapy artwork resources such as logos and fonts.

scrapy-logo.jpg
---------------

Main Scrapy logo, in JPEG format.

qlassik.zip
-----------

Font used for Scrapy logo. Homepage: https://www.dafont.com/qlassik.font

scrapy-blog.logo.xcf
--------------------

The logo used in Scrapy blog, in Gimp format.
